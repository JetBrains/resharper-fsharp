﻿namespace $projectName$

type Class1() = 
    member this.X = "F#"$caret$
